package com.mahdi.internship.InternShipProject.Candidat;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "activity")
public class Activity {

	@Id
	@GeneratedValue
	private long id;

	@Column(name = "Aname")
	private String Aname;

	@Column(name = "Aduration")
	private String ADuration;

	// private Set<Activity> acts = new HashSet<Activity>(0);

	protected Activity() {
	}

	public long getId() {
		return id;
	}

	public void setId(long idA) {
		this.id = idA;
	}

	public String getAname() {
		return Aname;
	}

	public void setAname(String aname) {
		Aname = aname;
	}

	public String getADuration() {
		return ADuration;
	}

	public void setADuration(String aDuration) {
		ADuration = aDuration;
	}

	/********************
	 * SOME ATEMPTS
	 * 
	 * @ManyToOne(fetch = FetchType.LAZY)
	 * @JoinColumn(name = "candidatid", nullable = false) public Candidat
	 *                  getCandidat() { return candidat; }
	 * 
	 *                  public void setCandidat(Candidat candidat) { this.candidat =
	 *                  candidat; }
	 * 
	 *                  public Set<Activity> getActs() { return acts; }
	 * 
	 *                  public void setActs(Set<Activity> acts) { this.acts = acts;
	 *                  }
	 *****/

}
