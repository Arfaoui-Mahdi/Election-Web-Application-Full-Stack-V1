package com.mahdi.internship.InternShipProject.Candidat;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "candidat")
public class Candidat {

	@Id
	@GeneratedValue
	private Long id;

	@Column(name = "name")
	private String name;

	@Column(name = "tdate")
	private Date targetDate;

	@Column(name = "pname")
	private String partyName;

	/**************************************/
	public Date getTargetDate() {
		return targetDate;
	}

	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}

	public void setId(Long id) {
		this.id = id;
	}

	protected Candidat() {
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getDate() {
		return targetDate;
	}

	public void setDate(Date date) {
		this.targetDate = date;
	}

	public String getPartyName() {
		return partyName;
	}

	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}

	/*****************
	 * SOME ATTEMPTS private Set<Activity> acts = new HashSet<Activity>(0);
	 * 
	 * /*---------------------
	 * 
	 * @OneToMany(fetch = FetchType.LAZY, mappedBy = "id") public Set<Activity>
	 *                  getActs() { return acts; }
	 * 
	 *                  public void setActs(Set<Activity> acts) { this.acts = acts;
	 *                  }
	 **************/

}
