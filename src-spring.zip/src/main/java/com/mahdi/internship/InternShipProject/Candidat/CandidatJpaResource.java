package com.mahdi.internship.InternShipProject.Candidat;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class CandidatJpaResource {

	@Autowired
	private CandidatJpaRepository obj;

	// method to retrieve all candidates data to use in the refreshCandidats()
	// function in the front
	@GetMapping("/candidats/data")
	public List<Candidat> getData() {
		return obj.findAll();
	}

	@GetMapping("/candidats/{id}")
	public Optional<Candidat> getOneData(@PathVariable long id) {
		return obj.findById(id);
	}

	@DeleteMapping("/candidats/{id}")
	public ResponseEntity<Void> deleteTodo(@PathVariable long id) {

		obj.deleteById(id);
		return ResponseEntity.noContent().build();
	}

	@PutMapping("/candidats/{id}")
	public ResponseEntity<Candidat> updateTodo(@PathVariable long id, @RequestBody Candidat candidat) {

		Candidat candidatUpdated = obj.save(candidat);

		return new ResponseEntity<Candidat>(candidatUpdated, HttpStatus.OK);
	}

	@PostMapping("/candidats")
	public ResponseEntity<Void> updateTodo(@RequestBody Candidat candidat) {

		Candidat createdCandidat = obj.save(candidat);

		// Location
		// Get current resource url

		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(createdCandidat.getId())
				.toUri();

		return ResponseEntity.created(uri).build();
	}

}
