package com.mahdi.internship.InternShipProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InternShipProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(InternShipProjectApplication.class, args);
	}

}
