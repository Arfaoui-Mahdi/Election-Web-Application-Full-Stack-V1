

insert into candidat (id , name , tdate, pname )
values (1,'Youcef Chahed' , sysdate() , 'Tahya Tunis');

insert into candidat (id , name , tdate, pname )
values (2,'Safi Saiid' , sysdate() , 'Independant');

insert into candidat (id , name , tdate, pname )
values (3,'Kais Said' , sysdate() , 'Independant');



insert into activity (id , Aname , Aduration )
values (1,'FootBall' , '2 Weeks');
