package com.mahdi.internship.InternShipProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InternShipProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
