import { Component, OnInit } from '@angular/core';
import { CandidatDataControllingService } from '../service/data/candidat-data-controlling.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-page',
  templateUrl: './admin-page.component.html',
  styleUrls: ['./admin-page.component.css']
})
export class AdminPageComponent implements OnInit {

  Candidats: Candidat[];
  message: string;


  constructor(private candidatService: CandidatDataControllingService,
    private router : Router) { }

  ngOnInit() {
    this.refreshCandidats()
  }

  refreshCandidats() {
    this.candidatService.retrieveAllCandidatData().subscribe(
      response => {
        console.log(response);
        this.Candidats = response;
      }
    )
  }



  hanfleDelete(id, name) {
    this.candidatService.deleteCandidat(id).subscribe(

      response => {
      this.message = `Delete of the Candidat ** ${name} ** Successful!`;
        this.refreshCandidats();

      }

    )

  }

  hanfleUpdate(id) {
    console.log(`update ${id}`)
    this.router.navigate(['candidats',id])
  }

  addCandidat() {
    this.router.navigate(['candidats',-1])
  }


}



export class Candidat {
  constructor(
    public id: number,
    public name: string,
    public partyName: string,
    public date: Date
  ) { }
}