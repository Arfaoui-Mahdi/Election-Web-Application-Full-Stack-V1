import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { AppComponent  } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AppRoutingModule } from './app-routing.module';
import { WelcomeComponent } from './welcome/welcome.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { LogoutComponent } from './logout/logout.component';
import { DataPageComponent } from './data-page/data-page.component';

import { HpageComponent } from './hpage/hpage.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AdminPageComponent } from './admin-page/admin-page.component';
import { UpdatesaveComponent } from './updatesave/updatesave.component';
import { HttpInterceptorService } from './service/http/http-interceptor.service';

@NgModule({
    imports: [
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        AppRoutingModule,
        HttpClientModule
        
    ],
    declarations: [
        AppComponent ,
        LoginComponent,
        RegisterComponent,
        WelcomeComponent,
        HeaderComponent,
        FooterComponent,
        LogoutComponent,
        DataPageComponent,
        HpageComponent,
        AdminPageComponent,
        UpdatesaveComponent,
        
        
    ],
    providers: [
        {provide: HTTP_INTERCEPTORS, useClass: HttpInterceptorService, multi: true }
     ],
    
    bootstrap: [AppComponent]
})
export class AppModule { }