import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HpageComponent } from './hpage.component';

describe('HpageComponent', () => {
  let component: HpageComponent;
  let fixture: ComponentFixture<HpageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HpageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HpageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
