import { Component, OnInit } from '@angular/core';
import { CandidatDataControllingService } from '../service/data/candidat-data-controlling.service';

@Component({
  selector: 'app-hpage',
  templateUrl: './hpage.component.html',
  styleUrls: ['./hpage.component.css']
})



export class HpageComponent implements OnInit {

  Candidats : Candidat[];
  message ="holaaaaa"  
  constructor(private candidatService : CandidatDataControllingService) { }

  ngOnInit() {
    this.refreshCandidats()
  }
  
  refreshCandidats(){
    this.candidatService.retrieveAllCandidatData().subscribe(
      response => {
        console.log(response);
        this.Candidats = response;
      }
    )
    }
  
  }
export class Candidat {
    constructor(
      public id: number,
      public name: string,
      public partyName: string,
      public date: Date
    ){}
  }