import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthCodeService {

  constructor(private router : Router) { }

  authentification(username,password){
    if(username==="internShip2019"&&password==="ElectoralProject")
    {
      sessionStorage.setItem('authenticaterUser', username);
      return true;}
     else{
    return false;
     }


  }

  isUserLoggedIn() {
    let user = sessionStorage.getItem('authenticaterUser')
    return !(user === null)
  }

  logout(){
    sessionStorage.removeItem('authenticaterUser');
    this.router.navigate(['candidats'])
    
  }
}
