import { TestBed } from '@angular/core/testing';

import { CandidatDataControllingService } from './candidat-data-controlling.service';

describe('CandidatDataControllingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CandidatDataControllingService = TestBed.get(CandidatDataControllingService);
    expect(service).toBeTruthy();
  });
});
