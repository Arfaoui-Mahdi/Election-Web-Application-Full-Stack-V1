import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Candidat } from '../../hpage/hpage.component';



@Injectable({
  providedIn: 'root'
})
export class CandidatDataControllingService {

  constructor(private http:HttpClient) { }

  
  retrieveAllCandidatData() 
    {
    return this.http.get<Candidat[]>(`http://localhost:8080/candidats/data`);
    }
   
    retrieveOneCandidatData(id) 
    {
    return this.http.get<Candidat>(`http://localhost:8080/candidats/${id}`);
    }

  
  deleteCandidat(id){

    return this.http.delete(`http://localhost:8080/candidats/${id}`)

  } 
  
  
  updateCandidat(id,candidat){

    return this.http.put(`http://localhost:8080/candidats/${id}`,candidat)
  }


  createCandidat(candidat){

    return this.http.post(`http://localhost:8080/candidats`,candidat)

  }
    

}

