import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatesaveComponent } from './updatesave.component';

describe('UpdatesaveComponent', () => {
  let component: UpdatesaveComponent;
  let fixture: ComponentFixture<UpdatesaveComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdatesaveComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatesaveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
