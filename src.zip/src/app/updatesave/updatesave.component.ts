import { Component, OnInit } from '@angular/core';
import { CandidatDataControllingService } from '../service/data/candidat-data-controlling.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Candidat } from '../admin-page/admin-page.component';

@Component({
  selector: 'app-updatesave',
  templateUrl: './updatesave.component.html',
  styleUrls: ['./updatesave.component.css']
})
export class UpdatesaveComponent implements OnInit {
 id : number;
 Candidat : Candidat;


  constructor(private candidatService : CandidatDataControllingService,
    private router : Router,
    private route: ActivatedRoute ) { }

  ngOnInit() {

    this.id = this.route.snapshot.params['id'];
    this.Candidat = new Candidat(this.id,'','',new Date());
    
    if(this.id!=-1) {
      this.candidatService.retrieveOneCandidatData(this.id)
          .subscribe (
            data => this.Candidat = data
          )
    }
  }

  saveCandidat() {
    if(this.id == -1) { 
      this.candidatService.createCandidat(this.Candidat)
          .subscribe (
            data => {
              console.log(data)
              this.router.navigate(['admin'])
            }
          )
    } else {
      this.candidatService.updateCandidat(this.id, this.Candidat)
          .subscribe (
            data => {
              console.log(data)
              this.router.navigate(['admin'])
            }
          )
    }
  }


}
